﻿namespace Unity.XR.PXR
{
    public enum SwitchEnum
    {
        S_ON=0,
        S_OFF=1
    }
}