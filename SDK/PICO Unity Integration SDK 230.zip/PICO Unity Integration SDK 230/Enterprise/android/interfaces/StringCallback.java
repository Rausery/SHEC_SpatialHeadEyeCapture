package com.picoxr.tobservice.interfaces;

public interface StringCallback {
    void CallBack(String var1);
}
