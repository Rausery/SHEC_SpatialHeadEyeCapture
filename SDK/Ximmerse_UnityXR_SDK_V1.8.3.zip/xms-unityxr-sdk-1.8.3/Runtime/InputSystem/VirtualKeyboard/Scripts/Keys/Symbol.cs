﻿using UnityEngine;

namespace Ximmerse.RhinoX
{
    public class Symbol : Key { }
}