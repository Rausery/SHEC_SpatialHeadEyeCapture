﻿using UnityEngine;

namespace Ximmerse.RhinoX
{
    public class Number : Key { }
}