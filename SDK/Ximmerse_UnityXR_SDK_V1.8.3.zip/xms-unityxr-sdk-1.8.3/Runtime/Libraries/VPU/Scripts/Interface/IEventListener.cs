namespace Ximmerse.Wrapper.XDeviceService.Interface
{
    public interface IEventListener
    {
        void OnEvent(int evt, int arg, int ud);
    }
}